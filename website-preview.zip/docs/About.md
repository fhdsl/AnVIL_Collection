
# About the Authors {-}

These credits are based on our [course contributors table guidelines](https://github.com/jhudsl/OTTR_Template/wiki/How-to-give-credits).

&nbsp;
&nbsp;

<!-- Authors of AnVIL modules have been listed as Content Contributors, under "AnVIL instructions". -->

|Credits|Names|
|-------|-----|
|**Technical**||
|Course Publishing Engineer and Maintainer| [Ava Hoffman] |
|Template Publishing Engineers|[Candace Savonen], [Carrie Wright]|
|Publishing Maintenance Engineer|[Candace Savonen]|
|Technical Publishing Stylists|[Carrie Wright], [Candace Savonen]|
|Package Developers ([ottrpal])|[John Muschelli], [Candace Savonen], [Carrie Wright]|


<!-- Author information -->

[FirstName LastName]: link to personal website
[Allie Cliffe]: https://alliecliffe.com/
[Katherine Cox]: https://katherinecox.github.io/
[Ava Hoffman]: https://www.avahoffman.com/
[Elizabeth Humphries]: https://www.linkedin.com/in/elizabeth-humphries-61202a103/
[John Muschelli]: https://johnmuschelli.com/
[Candace Savonen]: https://www.cansavvy.com/
[Carrie Wright]: https://carriewright11.github.io/

<!-- Links -->

[ottrpal]: https://github.com/jhudsl/ottrpal

<!-- Fill out this table using these instructions: https://github.com/jhudsl/OTTR_Template/wiki/How-to-give-credits

For JHU courses, You will need to add Ira as a credit:

|Content Publisher|[Ira Gooding]|
...
[Ira Gooding]: https://publichealth.jhu.edu/faculty/4130/ira-gooding
-->
